# utils.py
def get_animal_description(animal_id: int) -> str:
    # Возвращает описание животного по ID
    descriptions = {
        1: "Это удивительный слон, который любит воду.",
        2: "Это быстрый гепард, который обожает бегать.",
        # ...
    }
    return descriptions.get(animal_id, "Описание не найдено.")
