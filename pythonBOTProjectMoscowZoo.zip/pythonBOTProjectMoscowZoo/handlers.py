# handlers.py
from telegram import Update
from telegram.ext import CallbackContext, CommandHandler
from telegram.ext import Application, MessageHandler, filters

async def start(update: Update, context: CallbackContext) -> None:
    await update.message.reply_text(
        "Добро пожаловать в наш зоопарк! Нажмите /quiz, чтобы пройти викторину и найти своего тотемного животного!"
    )

async def help_command(update: Update, context: CallbackContext) -> None:
    await update.message.reply_text(
        "Этот бот проведет вас через викторину, чтобы найти ваше тотемное животное. Просто следуйте инструкциям."
    )

async def contact(update: Update, context: CallbackContext) -> None:
    await update.message.reply_text(
        "Для дополнительной информации свяжитесь с нами по email@example.com или по телефону +1234567890."
    )
