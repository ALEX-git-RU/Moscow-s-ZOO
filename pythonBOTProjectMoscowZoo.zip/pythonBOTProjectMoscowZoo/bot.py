# bot.py
from telegram import Update
from telegram.ext import Application, CallbackContext, CommandHandler, MessageHandler, ConversationHandler, filters
from config import BOT_TOKEN
from handlers import start, help_command, contact
from quiz import start_quiz, handle_answer, restart_quiz, QUESTION


def main() -> None:
    application = Application.builder().token(BOT_TOKEN).build()

    application.add_handler(CommandHandler('start', start))
    application.add_handler(CommandHandler('help', help_command))
    application.add_handler(CommandHandler('contact', contact))

    conversation_handler = ConversationHandler(
        entry_points=[CommandHandler('quiz', start_quiz)],
        states={
            QUESTION: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_answer)],
        },
        fallbacks=[CommandHandler('restart', restart_quiz)]
    )
    application.add_handler(conversation_handler)

    application.run_polling()

if __name__ == '__main__':
    main()
