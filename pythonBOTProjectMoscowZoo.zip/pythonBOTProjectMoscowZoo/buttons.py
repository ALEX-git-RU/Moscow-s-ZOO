# buttons.py
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

def create_buttons() -> InlineKeyboardMarkup:
    keyboard = [
        [InlineKeyboardButton("Начать викторину", callback_data='start_quiz')],
        [InlineKeyboardButton("Связаться с нами", callback_data='contact')],
        [InlineKeyboardButton("Попробовать еще раз", callback_data='restart_quiz')]
    ]
    return InlineKeyboardMarkup(keyboard)
