# quiz.py
from telegram import Update
from telegram.ext import CallbackContext, ConversationHandler, CommandHandler, MessageHandler, filters

QUESTION, ANSWER = range(2)

async def start_quiz(update: Update, context: CallbackContext) -> int:
    await update.message.reply_text(
        "Начнем викторину! Вот первый вопрос:"
    )
    await send_question(update, context)
    return QUESTION

async def send_question(update: Update, context: CallbackContext) -> None:
    await update.message.reply_text(
        "Какой ваш любимый тип животных?\n"
        "1. Млекопитающие\n"
        "2. Птицы\n"
        "3. Рептилии\n"
        "4. Насекомые"
    )

async def handle_answer(update: Update, context: CallbackContext) -> int:
    user_answer = update.message.text

    score = 0
    if user_answer == "1":
        score += 10
    # ...

    await update.message.reply_text(f"Ваш результат: {score}\n\nВаш тотемное животное: [описание животного].")
    await update.message.reply_photo(photo='https://example.com/image.jpg')
    await update.message.reply_text("Хотите попробовать еще раз? Нажмите /restart для повторного прохождения викторины.")
    return ConversationHandler.END

async def restart_quiz(update: Update, context: CallbackContext) -> int:
    await update.message.reply_text("Давайте начнем заново!")
    await send_question(update, context)
    return QUESTION
